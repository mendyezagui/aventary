---
name: routing-leak-finder
description: >-
  Find the leads a revenue team paid for that quietly went nowhere, from a CRM
  lead or opportunity export. Use this whenever someone asks about lead routing,
  speed-to-lead, unassigned or unowned leads, SLA misses, abandoned or dropped
  leads, duplicate leads, or territory/ownership overlap, or wants a Routing
  Health Score from a Salesforce / HubSpot / Pipedrive leads export. Trigger on
  phrases like "are leads getting routed," "which leads went nowhere," "run a
  routing leak finder," "are we missing our speed-to-lead SLA," or any time a
  user hands over a leads CSV and wants to know what's leaking. Runs entirely
  locally -- no data leaves the machine.
---

# Routing Leak Finder

Surfaces the leads that fell through routing cracks -- unowned, slow-to-touch,
abandoned, duplicated, or worked by two reps at once -- and produces a 0-100
Routing Health Score. It answers: "of the leads we paid to generate, how many is
our process quietly dropping?"

## Privacy (say this to the user, it matters)

This runs **locally and makes zero network calls**. The CSV never leaves the
user's machine -- nothing is uploaded or stored. The script is short and
dependency-free on purpose: anyone can read it and confirm there's no `requests`,
no `urllib`, no sockets.

## How to run

The user provides a CSV export of their **leads** (or open opportunities). Run:

```
python3 scripts/routing_leak_finder.py <path-to-their-csv>
```

Options: `--asof YYYY-MM-DD` to score as of a date (default today), and `--sla N`
to set the first-touch SLA in hours (default 24). Then present the printed report
and walk them through it.

Python 3.8+ standard library only -- no `pip install`.

## Expected columns

Maps common CRM names automatically. Ideal columns: Lead/Opportunity name,
Account/Company, Owner, Status/Stage, Created date, Last activity date, First
activity/response date, Email, Amount (optional), Region/Territory. Missing
columns are reported as the first finding, not an error.

## What it flags

- **Unowned** -- blank/unassigned owner
- **SLA miss** -- first touch slower than the SLA (default 24h), or never touched
- **Abandoned** -- 30+ days idle while still open, or never worked after 14 days
- **Duplicate** -- same email appears on more than one open lead
- **Split ownership** -- one account worked by two or more reps (territory overlap)

The Routing Health Score is a count-share-weighted penalty across these.

## Interpreting the result

- This scores routing **hygiene, not lead quality**. A slow-touched lead can
  still buy; a fast one can still be junk. The score is how many paid-for leads
  the process is dropping.
- Pair with **Pipeline X-Ray** (pipeline integrity) and **Forecast Stress Test**
  (forecast realism); all three roll up into the **Executive Scorecard**.
