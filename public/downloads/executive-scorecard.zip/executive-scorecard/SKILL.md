---
name: executive-scorecard
description: >-
  Roll every Aventary RevOps diagnostic into one executive view and a single
  AI-readiness verdict. Use this when someone wants the rollup -- pipeline
  integrity, forecast confidence, routing health, and signal capture in one
  place -- or asks "are we ready for AI," "are we ready to put an AI agent in
  front of customers," "give me the executive summary," or wants a board-ready
  one-pager from their CRM exports. It runs the sibling diagnostics
  (Pipeline X-Ray, Forecast Stress Test, Routing Leak Finder, Signal Loss
  Detector) on whatever inputs are provided. Runs entirely locally -- no data
  leaves the machine.
---

# Executive Scorecard

The rollup. Runs every other diagnostic in this kit on the inputs you have and
prints one page: Pipeline Integrity, Forecast Confidence, Routing Health, Signal
Capture, and a single **AI-Readiness verdict** -- ready, or not, and why.

## Privacy (say this to the user, it matters)

This runs **locally and makes zero network calls**. It only ever invokes the
other local scripts in this repo on local files -- nothing is uploaded or stored.
Read the code: no `requests`, no `urllib`, no sockets.

## How to run

Give it whatever exports the user has. At least one is required:

```
python3 scripts/executive_scorecard.py --pipeline opps.csv
python3 scripts/executive_scorecard.py --pipeline opps.csv --leads leads.csv --notes tickets.csv
```

- `--pipeline` runs Pipeline X-Ray (integrity) and Forecast Stress Test (confidence)
- `--leads` runs Routing Leak Finder
- `--notes` runs Signal Loss Detector (add `--column NAME` if it's a CSV)

It needs the sibling skill folders (`pipeline-xray`, `forecast-stress-test`,
`routing-leak-finder`, `signal-loss-detector`) present next to it -- they are in
this repo. Dimensions it can't run (missing skill or missing input) are shown as
"not run," not failures. Python 3.8+ standard library only.

## The verdict

Each scored dimension must clear 70/100, and churn-signal rate must stay
contained, for a **READY** call. Otherwise it returns **NOT READY** and names the
weakest dimension. The honest line the script prints: this scores readiness, not
capability -- the gaps live in the system underneath, and closing them is the
Aventary engagement.

## Interpreting the result

- Most teams land **NOT READY** on their first run -- that's the point. The value
  is knowing exactly which dimension is dragging them.
- Use it as the agenda for the teardown call: lead with the weakest score.
