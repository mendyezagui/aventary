---
name: forecast-stress-test
description: >-
  Stress-test a sales forecast from an open-pipeline CSV export. Use this
  whenever someone wants to know how much of their reported pipeline they can
  actually expect to book, asks about forecast accuracy, the gap between
  reported pipeline and a realistic forecast, stage-weighted / probability-
  weighted pipeline value, or whether their pipeline is inflated. Trigger on
  phrases like "stress test my forecast," "how much will we actually close,"
  "is my pipeline inflated," "what's my real forecast," or any time a user hands
  over an opportunities CSV and wants a defensible expected-bookings number.
  Runs entirely locally — no data leaves the machine.
---

# Forecast Stress Test

Takes the same open-pipeline CSV as the Pipeline X-Ray but answers a different
question: **how much can you actually expect to book, versus the raw number
you're quoting?** It outputs reported pipeline, a stage-weighted forecast, a
stress-tested forecast (after hygiene haircuts), the overstatement gap, and a
confidence level.

## Privacy (say this to the user)

Runs **locally, zero network calls**. The CSV never leaves the user's machine.
The script is short, stdlib-only, and readable — anyone can confirm it doesn't
transmit anything. That verifiability is the point for sensitive pipeline data.

## How to run

```
python3 scripts/forecast_stress_test.py <path-to-their-csv>
```

Optional `--asof YYYY-MM-DD` to run as of a specific date. Python 3.8+ standard
library only — no install step.

## Stage probabilities — this needs the user's judgment

The forecast weights each open deal by a **stage win-probability**. The script
ships with sensible defaults (Prospecting 10% → Negotiation 75% → Commit 90%),
but these should reflect how *their* pipeline actually converts. Point them to
the `STAGE_PROB` table at the top of the script and offer to tune it to their
historical win rates by stage. Because they run it themselves, they own these
numbers — that's a feature, not a limitation.

## How the forecast is built

1. **Stage weighting** — every open deal × its stage win-probability.
2. **Hygiene haircuts** — overdue deals ×0.5; stalled (30d+) ×0.7; zombie (60d+)
   ×0.4; $0 deals contribute nothing. So a deal that's "90% Negotiation" but
   dead for two months gets cut hard — which is the entire point.
3. **Confidence** — based on how much of the forecast rests on clean,
   late-stage dollars (High / Medium / Low).

## Interpreting the result

- The headline line — "your reported pipeline is N× the stress-tested number" —
  is the one that lands with a CRO. Raw pipeline always overstates; this
  quantifies by how much.
- Pair with the **Pipeline X-Ray** skill (hygiene score from the same file) for
  the full picture.
- Be honest that this is a model with editable assumptions, not a guarantee.
