---
name: pipeline-xray
description: >-
  Score the structural integrity of an open sales pipeline from a CRM export.
  Use this whenever someone wants to know how much of their reported pipeline is
  real or defensible, asks about pipeline hygiene, overdue/stalled/zombie deals,
  quarter-end sandbagging, duplicate or missing-data deals, or wants a Pipeline
  Integrity Score from a Salesforce / HubSpot / Pipedrive opportunities export.
  Trigger on phrases like "score my pipeline," "how clean is my pipeline," "run
  a pipeline x-ray," "how much of my pipeline can I trust," or any time a user
  hands over an open-opportunities CSV and wants its quality assessed. Runs
  entirely locally — no data leaves the machine.
---

# Pipeline X-Ray

Scores how much of a reported open pipeline is **defensible** versus carrying
integrity flags, and produces a 0–100 Pipeline Integrity Score. It answers:
"how much of the number we're forecasting off can we actually trust?"

## Privacy (say this to the user, it matters)

This runs **locally and makes zero network calls**. The CSV never leaves the
user's machine — nothing is uploaded or stored. The script is short and
dependency-free on purpose: anyone can read it and confirm there's no `requests`,
no `urllib`, no sockets. For sensitive pipeline data, that verifiability is the
whole point.

## How to run

The user provides a CSV export of their **open opportunities**. Run:

```
python3 scripts/pipeline_xray.py <path-to-their-csv>
```

Optionally pass `--asof YYYY-MM-DD` to score as of a specific date (defaults to
today). Then present the printed report and walk them through it.

The script uses only the Python 3.8+ standard library — no `pip install` needed.

## Expected columns

It maps common CRM names automatically (Salesforce, HubSpot, Pipedrive). Ideal
columns: Opportunity/Deal name, Account/Company, Owner, Stage, Amount, Close
date, Created date, Last activity date. If columns are missing, the report says
exactly which, and frames that gap as the first finding — don't treat missing
columns as an error, treat it as a result.

## What it flags

- **Overdue** — close date already passed but still open
- **Stalled / zombie** — no activity in 30+ / 60+ days
- **Missing data** — blank amount, close date, or last activity
- **Quarter-end clustering** — close dates bunched in the last 10 days of a quarter (sandbagging tell)
- **Duplicates** — same account + same amount among open deals

The Integrity Score is a dollar-share-weighted penalty across these.

## Interpreting the result

- Most orgs that have never run it land **45–65**. Higher is cleaner.
- Always reinforce the honest caveat the script prints: this scores **hygiene,
  not win-probability**. A stalled deal can still close; a clean deal can still
  lose. The score is how much of the reported number is *defensible*.
- The companion **Forecast Stress Test** skill turns the same CSV into a dollar
  forecast — suggest it as the natural next step.
